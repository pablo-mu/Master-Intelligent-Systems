from launch_ros.actions import Node

from launch import LaunchDescription
from launch.actions import (RegisterEventHandler, EmitEvent, LogInfo)
from launch.event_handlers import (OnProcessExit, OnShutdown)
from launch.events import Shutdown

from machinevisiontoolbox.base import *
from machinevisiontoolbox import *
from spatialmath.base import *
from spatialmath import *

import numpy as np

import ibvs.init_parameters as init_params

# Parameters for the IBVS system
params = {
    'camera_pose': SE3.Trans(1, 1, -3) * SE3.Rz(0.6),
    'lmbda': 0.05,
    'eterm': 0.000001,
    'p': mkgrid(2, side=0.5, pose=SE3.Tz(2)),
    'pose_g' : SE3.Trans(-1, -1, 2),
    'p_star' : 200 * np.array([[-1, -1, 1, 1], [-1, 1, 1, -1]])  
}

params['camera_pose'] = init_params.prepare_parameters(params['camera_pose'].A)
params['p'] = init_params.prepare_parameters(params['p'])
params['pose_g'] = init_params.prepare_parameters(params['pose_g'].A)
params['p_star'] = init_params.prepare_parameters(params['p_star'])


def generate_launch_description():
    ld = LaunchDescription()
    
    # Create the feature extractor node
    feature_extractor_node = Node(
        package='ibvs',
        executable='feature_extractor',
        name='feature_extractor',
        parameters=[params]
    )
    
    # Create the controller node
    controller_node = Node(
        package='ibvs',
        executable='controller',
        name='controller',
        parameters = [params]
    )
    
    # Create the actuator node
    actuator_node = Node(
        package='ibvs',
        executable='actuator',
        name='actuator',
        parameters = [params]
    )
    
    # Add the nodes to the launch description
    ld.add_action(actuator_node)
    ld.add_action(controller_node)
    ld.add_action(feature_extractor_node)
    
    # Shutdown launcher when nodes exit
    fe_exit_event = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=feature_extractor_node,
            on_exit=[
                LogInfo(msg="feature_extractor exited"),
                EmitEvent(event=Shutdown(reason='feature_extractor exited'))]
        )
    )
    
    cntrl_exit_event = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=controller_node,
            on_exit=[
                LogInfo(msg="controller exited"),
                EmitEvent(event=Shutdown(reason='controller exited'))]
        )
    )
    
    act_exit_event = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=actuator_node,
            on_exit=[
                LogInfo(msg="actuator exited"),
                EmitEvent(event=Shutdown(reason='actuator exited'))]
        )
    )
    
    ld.add_action(fe_exit_event)
    ld.add_action(cntrl_exit_event)
    ld.add_action(act_exit_event)
    
    return ld