import rclpy
from rclpy.node import Node

from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Bool


import ibvs.communication as comm

from machinevisiontoolbox.base import *
from machinevisiontoolbox import *
from spatialmath.base import *
from spatialmath import *

import time

import ibvs.init_parameters as init_params
class Actuator(Node):
    def __init__(self):
        super().__init__('actuator')
        
        # Declare parameters
        self.declare_parameter('lmbda',0.0)
        self.declare_parameter('camera_pose', "")
        
        # Load parameters from the Launch file
        self.lmbda = self.get_parameter('lmbda').get_parameter_value().double_value
        camera_pose = init_params.parameters_to_ndarray(self.get_parameter('camera_pose').get_parameter_value().string_value)
        self.camera = CentralCamera.Default(pose=SE3(camera_pose))
        
        self.c_pose_history = []
        # Prepare publisher
        self.publisher_ = self.create_publisher(Float64MultiArray, 'camera_pose', 10)
        
        # Prepare subscriber
        self.subscription = self.create_subscription(
            Float64MultiArray,
            'vel',
            self.actuate,
            10
        )
        
        
    def actuate(self, msg):
        # Receive the velocity via msg
        self.get_logger().info('Received velocity: "%s"' % msg)
        vel = comm.msg_to_ndarray(msg)
        self.Td = SE3.Delta(vel)
        
        # Move the robot
        self.camera.pose @= self.Td
        
        # Store new camera pose
        self.c_pose_history.append(self.camera.pose.A)
        # Save history to file
        np.save('/home/pablo/sjk015/entrega_ros/c_pose_history.npy', self.c_pose_history)
        # Send the new pose to the feature extractor
        msg = comm.prepare_msg(self.camera.pose.A)
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing camera pose: "%s"' % msg.data)
    
def main(args = None):
    rclpy.init(args=args)
    actuator = Actuator()
    
    rclpy.spin(actuator)
    
    actuator.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()
        
        