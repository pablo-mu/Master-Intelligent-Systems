import rclpy
from rclpy.node import Node

from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Bool


import ibvs.communication as comm

from machinevisiontoolbox.base import *
from machinevisiontoolbox import *
from spatialmath.base import *
from spatialmath import *

import time
import sys

import ibvs.init_parameters as init_params

class Controller(Node):
    def __init__(self):
        super().__init__('controller')
        
        # Declare parameters
        self.declare_parameter('lmbda',0.0)
        self.declare_parameter('eterm',0.0)
        self.declare_parameter('camera_pose', "")
        self.declare_parameter('p_star', "")
        
        # Load parameters from the Launch file
        self.lmbda = self.get_parameter('lmbda').get_parameter_value().double_value
        self.eterm = self.get_parameter('eterm').get_parameter_value().double_value
        camera_pose = init_params.parameters_to_ndarray(self.get_parameter('camera_pose').get_parameter_value().string_value)
        self.camera = CentralCamera.Default(pose=SE3(camera_pose))
        self.p_star = init_params.parameters_to_ndarray(self.get_parameter('p_star').get_parameter_value().string_value) + np.c_[self.camera.pp]
        
        self.v_history = []
        
        # Prpeare Subscriber
        self.subscription = self.create_subscription(
            Float64MultiArray,
            'feature_data',
            self.compute_velocity,
            10
        )
        
        self.camera_sub = self.create_subscription(
            Float64MultiArray,
            'camera_pose',
            self.camera_update,
            10
        )
        
        # Prepare the publisher
        self.publisher_ = self.create_publisher(Float64MultiArray, 'vel', 10)
        
        # Log eterm and lambda
        self.get_logger().info('lambda: %s' % self.lmbda)
        self.get_logger().info('eterm: %s' % self.eterm)
        
    def compute_velocity(self, msg):
        # Extract the feature data
        self.get_logger().info('Received uv: "%s"' % msg)
        uv = comm.msg_to_ndarray(msg)
            
        self.e = uv -self.p_star # Compute the error
        self.e = self.e.flatten('F') # Flatten the error
        self.J = self.camera.visjac_p(uv, 1) # Compute the visual Jacobian, 1 is the depth for simplicity
            
        try:
            v = -self.lmbda * np.linalg.pinv(self.J) @ self.e # Compute the velocity
        except np.linalg.LinAlgError:
            sys.exit("Singular Matrix")
        
        # Store v in file
        self.v_history.append(v)
        np.save('/home/pablo/sjk015/entrega_ros/v.npy', self.v_history)
            
        # Stop the loop if the velocity is very small
        if(np.linalg.norm(v) < self.eterm):
            sys.exit("Converged")
        
        # Limit the velocity of the robot
        self.get_logger().info('Velocity: %s' % v)
        if(np.linalg.norm(v) > 0.5):
            v = smbase.unitvec(v) * 0.5

        # Prepare the message
        msg = comm.prepare_msg(v)
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing velocity: "%s"' % msg)
            
    def camera_update(self, msg):
        # Read the msg
        pose = comm.msg_to_ndarray(msg)
        # Update the camera pose
        self.camera.pose = SE3(pose)


def main(args=None):
    rclpy.init(args=args)

    controller = Controller()

    rclpy.spin(controller)

    controller.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()