import base64
from std_msgs.msg import Float64MultiArray, MultiArrayDimension
from std_msgs.msg import Bool
import numpy as np


def prepare_msg(array):
    # Convert numpy array, flatten and then list
    data = array.flatten().tolist()
    # Compose message
    msg = Float64MultiArray()
    msg.data = data
    # Encode shape information in layout.dim
    msg.layout.dim = [MultiArrayDimension(size=d) for d in array.shape]
    return msg

def msg_to_ndarray(msg):
    # Extract shape from the message
    shape = tuple(dim.size for dim in msg.layout.dim)
    # Convert data back to numpy array and reshape
    data = np.array(msg.data).reshape(shape)
    return data
