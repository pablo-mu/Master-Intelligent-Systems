import numpy as np
import base64
from std_msgs.msg import String

def prepare_parameters(array, delimiter = "&"):
    return f"{base64.b64encode(array.tobytes()).decode('utf-8')}{delimiter}{array.dtype.name}{delimiter}{array.shape}"

# Recover original numpy array

def parameters_to_ndarray(parameters, delimiter = "&"):
    array, dtype, shape = parameters.split(delimiter)
    shape = tuple(map(int,shape.strip("(").strip(")").split(",")))
    array = base64.b64decode(array)
    return np.frombuffer(array, dtype=dtype).reshape(shape)
