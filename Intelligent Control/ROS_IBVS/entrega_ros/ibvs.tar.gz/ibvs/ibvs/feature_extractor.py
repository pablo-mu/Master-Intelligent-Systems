import rclpy
from rclpy.node import Node

from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Bool

from machinevisiontoolbox.base import *
from machinevisiontoolbox import *
from spatialmath.base import *
from spatialmath import *

import time


import ibvs.communication as comm

import ibvs.init_parameters as init_params


class FeatureExtractor(Node):
    def __init__(self):
        super().__init__('feature_extractor')
        
        # Declare parameters
        self.declare_parameter('camera_pose', "")
        self.declare_parameter('p', "")
        self.declare_parameter('pose_g', "")
        
        # Load parameters from the Launch file
        camera_pose = init_params.parameters_to_ndarray(self.get_parameter('camera_pose').get_parameter_value().string_value)
        self.camera = CentralCamera.Default(pose=SE3(camera_pose))
        self.P = init_params.parameters_to_ndarray(self.get_parameter('p').get_parameter_value().string_value)
        self.pose_g = SE3(init_params.parameters_to_ndarray(self.get_parameter('pose_g').get_parameter_value().string_value))
        
        # Prepare publisher
        self.publisher_ = self.create_publisher(Float64MultiArray, 'feature_data', 10)
        # Prepare subscriber
        self.subscription = self.create_subscription(
            Float64MultiArray,
            'camera_pose',
            self.update_camera_pose,
            10
        )
        
        self.uv_history = [] # Store the history of uv
        start_time = time.time()
        while time.time() - start_time < 1:
            pass
        
        # First call
        self.compute_pose()
        
    def compute_pose(self):
        # Compute the camera pose
        uv = self.camera.project_point(self.P)
        
         # Store uv in file
        self.uv_history.append(uv)
        np.save('/home/pablo/sjk015/entrega_ros/uv.npy', np.array(self.uv_history))
        # Prepare the message
        msg = comm.prepare_msg(uv)
        # Publish the message
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing uv: "%s"' % msg.data)
    
    def update_camera_pose(self, msg):
        # Extract the camera pose
        data = comm.msg_to_ndarray(msg)
        # Update the camera pose
        self.camera.pose = SE3(data)
        # Compute the new pose
        self.compute_pose()

def main(args=None):
    rclpy.init(args=args)

    feature_extractor = FeatureExtractor()

    rclpy.spin(feature_extractor)

    feature_extractor.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()